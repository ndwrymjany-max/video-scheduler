import os, sqlite3, uuid
from datetime import datetime
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

BASE = Path(__file__).parent
UPLOADS = BASE / "uploads"
UPLOADS.mkdir(exist_ok=True)
DB = BASE / "scheduler.db"
app = FastAPI(title="Video Scheduler")
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

def init_db():
    with sqlite3.connect(DB) as c:
        c.execute("""CREATE TABLE IF NOT EXISTS posts (
            id TEXT PRIMARY KEY, filename TEXT, caption TEXT, publish_at TEXT,
            status TEXT, created_at TEXT
        )""")
init_db()

@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/terms", response_class=HTMLResponse)
def terms():
    return (BASE / "terms.html").read_text(encoding="utf-8")

@app.get("/privacy", response_class=HTMLResponse)
def privacy():
    return (BASE / "privacy.html").read_text(encoding="utf-8")

@app.get("/api/posts")
def posts():
    with sqlite3.connect(DB) as c:
        rows=c.execute("SELECT id,filename,caption,publish_at,status,created_at FROM posts ORDER BY created_at DESC").fetchall()
    return [{"id":r[0],"filename":r[1],"caption":r[2],"publish_at":r[3],"status":r[4],"created_at":r[5]} for r in rows]

@app.post("/api/posts")
async def create_post(video: UploadFile=File(...), caption: str=Form(""), publish_at: str=Form("")):
    ext=Path(video.filename or "").suffix.lower()
    if ext not in {".mp4",".mov",".webm"}:
        return JSONResponse({"error":"صيغة الفيديو غير مدعومة. استخدم MP4 أو MOV أو WEBM."},status_code=400)
    post_id=uuid.uuid4().hex
    filename=post_id+ext
    dest=UPLOADS/filename
    size=0
    with dest.open("wb") as out:
        while True:
            chunk=await video.read(1024*1024)
            if not chunk: break
            size+=len(chunk)
            if size>100*1024*1024:
                dest.unlink(missing_ok=True)
                return JSONResponse({"error":"حجم الملف أكبر من 100 MB في هذه النسخة."},status_code=413)
            out.write(chunk)
    now=datetime.utcnow().isoformat(timespec="seconds")+"Z"
    status="مسودة" if not publish_at else "مجدول (غير متصل بتيك توك)"
    with sqlite3.connect(DB) as c:
        c.execute("INSERT INTO posts VALUES(?,?,?,?,?,?)",(post_id,filename,caption,publish_at,status,now))
    return {"ok":True,"id":post_id,"status":status}

@app.delete("/api/posts/{post_id}")
def delete_post(post_id: str):
    with sqlite3.connect(DB) as c:
        row=c.execute("SELECT filename FROM posts WHERE id=?",(post_id,)).fetchone()
        if not row: return JSONResponse({"error":"المقطع غير موجود"},status_code=404)
        c.execute("DELETE FROM posts WHERE id=?",(post_id,))
    (UPLOADS/row[0]).unlink(missing_ok=True)
    return {"ok":True}
