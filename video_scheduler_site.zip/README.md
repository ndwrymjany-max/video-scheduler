# Video Scheduler (prototype)

Arabic mobile-friendly video queue prototype using FastAPI.

## Local run
1. `pip install -r requirements.txt`
2. `uvicorn main:app --host 0.0.0.0 --port 8000`
3. Open `http://localhost:8000`

This prototype saves uploaded video files and captions in a local database. It does NOT publish to TikTok. It is not production-secure; before public use, add authentication, secure storage, retention/deletion controls, and official TikTok OAuth/API integration with approved scopes. Render free services may spin down and ephemeral disk storage may not persist; configure persistent storage or external storage/database before relying on uploads.
